package com.example.messangerapplication;

import android.content.Intent;
import android.os.Parcelable;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

public class ViewHolder extends RecyclerView.ViewHolder {

    RelativeLayout mess;
    TextView sender;
    ImageView imageView;
    TextView message;
    TextView time;
    ViewHolder(View itemView) {
        super(itemView);
        imageView = itemView.findViewById(R.id.message_image);
        mess = itemView.findViewById(R.id.message);
        time = itemView.findViewById(R.id.time);
        sender = itemView.findViewById(R.id.sender);
        message = itemView.findViewById(R.id.message_item);

    }
}
